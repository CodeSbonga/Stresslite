package com.example.project100.Domain

data class BannerModel(val url:String="")
