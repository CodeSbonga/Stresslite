package com.example.project100.Domain

data class CategoryModel(val title:String="",val id:Int=0) {
    class Viewholder {

    }
}
