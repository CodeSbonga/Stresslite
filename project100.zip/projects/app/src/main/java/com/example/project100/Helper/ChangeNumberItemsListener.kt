package com.uilover.project195.Helper

interface ChangeNumberItemsListener {
    fun onChanged()
}